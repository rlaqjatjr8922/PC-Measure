import base64
import json
import ipaddress
import socket
from urllib.parse import urlparse

import httpx

from mcp.server import MCPServer
from mcp.types import TextContent, ImageContent


# ==========================================
# 설정
# ==========================================

HOST = "0.0.0.0"
PORT = 8001

# 최대 응답 크기: 20MB
MAX_RESPONSE_SIZE = 20 * 1024 * 1024

# 최대 요청 시간
MAX_TIMEOUT = 120.0

# localhost / 사설 IP 접근 허용
# Cloudflare 같은 공인 URL만 쓸 거면 False
ALLOW_PRIVATE_IP = False


# ==========================================
# MCP 서버
# ==========================================

mcp = MCPServer(
    "HTTP Bridge",
    instructions="""
범용 HTTP API 호출용 MCP 서버입니다.

http_request 도구를 사용하여
GET, POST, PUT, PATCH, DELETE 요청을 보낼 수 있습니다.

JSON, 텍스트, HTML, 이미지 응답을 지원합니다.
"""
)


# ==========================================
# URL 검사
# ==========================================

def validate_url(url: str):
    parsed = urlparse(url)

    if parsed.scheme not in ("http", "https"):
        raise ValueError(
            "http:// 또는 https:// URL만 사용할 수 있습니다."
        )

    hostname = parsed.hostname

    if not hostname:
        raise ValueError(
            "URL에 hostname이 없습니다."
        )

    if ALLOW_PRIVATE_IP:
        return

    try:
        results = socket.getaddrinfo(
            hostname,
            None,
            type=socket.SOCK_STREAM,
        )

    except socket.gaierror:
        raise ValueError(
            f"DNS 조회 실패: {hostname}"
        )

    checked_ips = set()

    for result in results:
        ip_text = result[4][0]

        if ip_text in checked_ips:
            continue

        checked_ips.add(ip_text)

        try:
            ip = ipaddress.ip_address(ip_text)

        except ValueError:
            continue

        if (
            ip.is_private
            or ip.is_loopback
            or ip.is_link_local
            or ip.is_multicast
            or ip.is_reserved
            or ip.is_unspecified
        ):
            raise ValueError(
                f"사설/로컬 IP 접근 차단: {ip}"
            )


# ==========================================
# HTTP 요청 도구
# ==========================================

@mcp.tool(
    name="http_request",
    description=(
        "HTTP/HTTPS API를 호출합니다. "
        "GET, POST, PUT, PATCH, DELETE를 지원합니다. "
        "headers, query, JSON body, text body를 전달할 수 있습니다. "
        "이미지 응답은 이미지로 반환합니다."
    ),
    structured_output=False,
)
async def http_request(
    url: str,
    method: str = "GET",
    headers: dict[str, str] | None = None,
    query: dict | None = None,
    body: dict | list | str | None = None,
    timeout: float = 30.0,
) -> list[TextContent | ImageContent]:

    # --------------------------
    # URL 검사
    # --------------------------

    validate_url(url)

    method = method.upper().strip()

    allowed_methods = {
        "GET",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
    }

    if method not in allowed_methods:
        raise ValueError(
            "method는 GET, POST, PUT, PATCH, DELETE 중 하나여야 합니다."
        )

    # --------------------------
    # timeout 제한
    # --------------------------

    if timeout <= 0:
        timeout = 30.0

    if timeout > MAX_TIMEOUT:
        timeout = MAX_TIMEOUT

    # --------------------------
    # 요청 옵션
    # --------------------------

    request_options = {
        "method": method,
        "url": url,
        "headers": headers or {},
        "params": query or {},
        "timeout": timeout,

        # 다른 주소로 자동 이동하지 않음
        "follow_redirects": False,
    }

    # --------------------------
    # Body
    # --------------------------

    if body is not None:

        if isinstance(body, (dict, list)):
            request_options["json"] = body

        else:
            request_options["content"] = str(body)

    # --------------------------
    # 실제 HTTP 요청
    # --------------------------

    async with httpx.AsyncClient() as client:

        response = await client.request(
            **request_options
        )

    raw = response.content

    # --------------------------
    # 응답 크기 검사
    # --------------------------

    if len(raw) > MAX_RESPONSE_SIZE:

        raise ValueError(
            f"응답이 너무 큽니다: "
            f"{len(raw):,} bytes "
            f"(최대 {MAX_RESPONSE_SIZE:,} bytes)"
        )

    content_type = response.headers.get(
        "content-type",
        ""
    )

    mime_type = (
        content_type
        .split(";")[0]
        .strip()
        .lower()
    )

    # ==========================================
    # 이미지
    # ==========================================

    if mime_type.startswith("image/"):

        encoded = base64.b64encode(
            raw
        ).decode("ascii")

        return [
            TextContent(
                type="text",
                text=json.dumps(
                    {
                        "status": response.status_code,
                        "url": str(response.url),
                        "content_type": mime_type,
                        "size": len(raw),
                    },
                    ensure_ascii=False,
                    indent=2,
                ),
            ),

            ImageContent(
                type="image",
                data=encoded,
                mime_type=mime_type,
            ),
        ]

    # ==========================================
    # JSON
    # ==========================================

    if (
        mime_type == "application/json"
        or mime_type.endswith("+json")
    ):

        try:
            data = response.json()

            result = {
                "status": response.status_code,
                "url": str(response.url),
                "content_type": mime_type,
                "body": data,
            }

            return [
                TextContent(
                    type="text",
                    text=json.dumps(
                        result,
                        ensure_ascii=False,
                        indent=2,
                    ),
                )
            ]

        except Exception:
            pass

    # ==========================================
    # 텍스트 / HTML / XML
    # ==========================================

    if (
        mime_type.startswith("text/")
        or "html" in mime_type
        or "xml" in mime_type
        or "javascript" in mime_type
    ):

        result = {
            "status": response.status_code,
            "url": str(response.url),
            "content_type": mime_type,
            "body": response.text,
        }

        return [
            TextContent(
                type="text",
                text=json.dumps(
                    result,
                    ensure_ascii=False,
                    indent=2,
                ),
            )
        ]

    # ==========================================
    # 기타 바이너리
    # ==========================================

    encoded = base64.b64encode(
        raw
    ).decode("ascii")

    result = {
        "status": response.status_code,
        "url": str(response.url),
        "content_type": mime_type,
        "size": len(raw),
        "base64": encoded,
    }

    return [
        TextContent(
            type="text",
            text=json.dumps(
                result,
                ensure_ascii=False,
                indent=2,
            ),
        )
    ]


# ==========================================
# 실행
# ==========================================

if __name__ == "__main__":

    print("=" * 50)
    print(" HTTP Bridge MCP Server")
    print("=" * 50)
    print()
    print(f"MCP 주소:")
    print(f"http://127.0.0.1:{PORT}")
    print()
    print("종료: Ctrl+C")
    print()

    mcp.run(
        transport="streamable-http",

        host=HOST,
        port=PORT,

        # 핵심
        # 기본 /mcp 대신 루트 / 사용
        streamable_http_path="/",

        # 상태 없는 HTTP 방식
        stateless_http=True,

        # POST 응답을 JSON으로
        json_response=True,
    )